# mylist  = ["prsahant","ashish","komal","ankush","ashish", 77, "sandip", 60,54, 60.5,]
# print(mylist)
# print(type(mylist))
# print(id(mylist))
# print(mylist[0])
# print(mylist[1])
# print(mylist[2])
# print(mylist[-1])
# print(mylist[2:5])
# print(mylist[5:])
# print(mylist[:1])
# print(mylist[1:8:2])
# print(mylist[:])
# print(mylist[::-1]) 

# ----------------------------------------------------------------
# add ele at Index
# mylist[4]= "komal"
# print(mylist)

# ------------------------------------------------------------------
# if else statement
# if "ankush" in mylist:
#     print("ankush is available")
# else:
#     print("ankush is not available")

# --------------------------------------------
#append() method is used to add an element at the end of the list.
# mylist.append("prashant")
# print(mylist)

# -----------------------------------------------------

# insert() method is used to add an element at a specific index of the list.
# mylist.insert(2,"prashant")
# print(mylist)

# -------------------------------------------------------------
#  remove() method is used to remove an element from the list.
# mylist.remove("ashish")
# print(mylist)

# ---------------------------------------------------------------
# copy
# newlist = mylist.copy()
# print(mylist)
# print(newlist)

# ------------------------------------------------------------------
# mylist = [['prashat', 'jha'],['85.56'],[440022,"yyy"]]
# print("example of multidimensional list:",mylist)
# # print(mylist[row][col])
# print(mylist[0][0]) #prashant
# print(mylist[0][1]) #jha    
# print(mylist[1][0]) #85.56
# print(mylist[2][0]) #440022
# print(mylist[2][1]) #yyy
# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# [        0     ,    1  ]
# 0 = ['prashant', 'jha']
# 1 = ['85.56']
# 2 = [440022, "yyy"]

# ------------------------------------------------------------------------

# multiply strings in list
# list1 = ["prashant", "jha"]
# print(list1*2)

# -------------------------------------------------------------------------
# conacatenation of list
# list2 = [50,25.50]
# print(list1 + list2)

# --------------------------------------------------------------------------

# delete list
# list2 = [50,25.50,"prashant"]
# del list2   #delete the entire list2 from memory
# del list2[2] delete word at index 2 from list2
# print(list2) # it will give error because list2 is deleted from memory and it cannot be accessed.
# list2.clear() # it will clear the content of list2
# print(list2)

# ---------------------------------------------------------------------------

# name = "sakharam"
# print(name)
# myname = list(name) #type casting of string into list
# print(myname) # we have used list constructor

# ---------------------------------------------------------------------
#reverse of list
# mylist = [40,30,20,10]
# mylist.reverse()
# print(mylist)

# -----------------------------------------------------------------------------

# sorting of list
# mylist = [40,30,20,10]
# mylist.sort() # it will sort the list in ascending order
# print(mylist)
# mylist.sort(reverse=True) # it will sort the list in descending order
# print(mylist)
# default sorting is in ascending order
# default sorting for string is in alphabetical order
# we should take care that the list should contain homogeneous data otjerwise we will get the typeerror

# --------------------------------------------------------------------------------------------------------

# alising
# mylist = [40,30,20,10]
# newlist = mylist # it will create a new reference variable newlist which will point to the same memory location as mylist
# print(id(mylist))
# print(id(newlist))
# mylist[0] = "prashant"
# print(mylist)
# print(newlist)

# ------------------------------------------------------------------------------------------

# arr = [[1,2,3,4],
#        [4,5,6,7,], 
#        [8,9,10,11],
#        [12,13,14,15]]
# for i in range(0,4):
#     print(arr[i].pop())     #pop always removes the last element   

# --------------------------------------------------------------------------------------------
# arr = [1,2,3,4,5,6]
# for i in range(1,6):
#     arr[i-1] = arr[i]
# for i in range(0,6):
#     print(arr[i], end=" ")

# --------------------------------------------------------------------------------------------

# a = [1,2,3,4,5,6,7,8,9]
# a[::2] = 10,20,30,40,50,60
# print(a)
 
# --------------------------------------------------------------------------------------------

# a=[1,2,3,4,5]
# print(a[3:0:-1])

# --------------------------------------------------------------------------------------------
