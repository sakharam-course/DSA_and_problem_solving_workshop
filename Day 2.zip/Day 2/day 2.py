# indexing

# name = "sakharam"
# #index = 01234567
# print(name[0]) #s
# print(name[1]) #a
# print(name[-1]) #m
# #print(name[9]) #error index out of range
# print(name[0:5]) #sakha index 0 to end - 1
# print(name[2:]) #kharam second index till end
# print(name[:7]) #sakhara first letter to end - 1
# print(name[:]) #sakharam whole string
# print(name[0:7:2]) #skaa index 0 to end - 1 with increment of 2
# print(name[::-1]) #marahkas reverse of the string
 
# -----------------------------------------------------------------------------

# s = "Python is a High level programming Language"
# print(s.lower())
# print(s.upper()) 
# print(s.title()) #first letter of each word is capital.
# print(s.capitalize()) #first letter of the string is capital and rest are small.
# print(s.swapcase()) #upper to lower case and lower to upper case

# ---------------------------------------------------------------------------------------

# print("subject marks")
# phy = 50
# chem = 60
# maths = 70
# print("physics = {}, chemistry = {}, maths = {}".format(phy,chem,maths))
# print("physics = {0}, chemistry = {1}, maths = {2}".format(phy,chem,maths)) 
# print("physics = {x}, chemistry = {y}, maths = {z}".format(x=phy, y=chem, z=maths)) 
# total = phy + chem + maths
# print("total marks",f"{total}")
# print("roll no= ","7".zfill(4))

# --------------------------------------------------------------------------------------

# looping
# for (initialization, condition, increment/decrement):
# for i in range(5): #i = 0,1,2,3,4
#     print(i)
    
# for i in range(1,6): #i = 1,2,3,4,5  1 to end - 1
#     print(i)

# for i in range(1,11,2): #i = 1,3,5,7,9  1 to end - 1 with increment of 2
#     print(i)

# for i in range(1,11):  #table of 2
#     print(i*2)

# for i in range(1,11): #table from 1 to 10 vertically
#     print(i*2,"\t", i*3, "\t", i*4, "\t", i*5, "\t", i*6, "\t", i*7, "\t", i*8, "\t", i*9, "\t", i*10)

# print()
# for i in range(1,11): #table from 11 to 20 vertically
#     print(i*11,"\t", i*12, "\t", i*13, "\t", i*14, "\t", i*15, "\t", i*16, "\t", i*17, "\t", i*18, "\t", i*19, "\t", i*20)
    
#---------------------------------------------------------------------------------------------------------------------------------

# string
# name = "sakharam"
# for i in name:
#     print(i)
    
# wap to remove duplicate using for loop
# name = "sakharam"
# new_name = "" #empty string
# for i in name:
#     if i not in new_name:   #if i is not present in new_name then only add it to new_name
#         new_name = new_name + i #conatenation of string
#print(name)
# print(new_name)

# for i in range(5,0,-1):         #(initialization, condition(greater than,less than), decrement with 1)
#     print(i)
    
# for i in range(10,0,-2):        #(initialization, condition(greater than,less than), decrement with 2)
#     print(i)

# ------------------------------------------------------------------------------------------------------------

# wap to reverse a string using forr loop
# name  = "sakharam"
# n = len(name) #length of the string n = 8
# print(n)
# new_name = "" #empty string 
# for i in range(n-1, -1, -1):  #(7,-1,-1) 
#     new_name = new_name + name[i] 
# print(new_name)

# -------------------------------------------------------------------------------------------------------------

# wap to check the string whether it is palindrome or not

# name = "racecar"
# print(name)
# print(name[::-1]) #reverse of the string
# if name == name[::-1]: #if original string is equal to reverse of the string then it is palindrome
#     print("the string is palindrome")   
# else:
#     print("the string is not palindrome")