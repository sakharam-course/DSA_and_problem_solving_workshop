# mytuple = ("prashant", "ashish", "rahul", "sandip", "komal", "ankush", "rajesh", 23.5, 77, "sandip")
# print(mytuple)
# print(type(mytuple))

# mytuple[2]="sunil"
# print(mytuple)

# ----------------------------------------------------------------------------------------------------

# init_tuple = ()
# print(init_tuple.__len__())

# print(type(init_tuple))

# ----------------------------------------------------------------------------------

# init_tuple_a = 'a','b'
# init_tuple_b = ('a','b')
# print(init_tuple_a == init_tuple_b)

# ----------------------------------------------------------------------------------

# init_tuple_a = '1', '2'
# init_tuple_b = '3', '4'
# print(init_tuple_a + init_tuple_b)

# ----------------------------------------------------------------------------------

# init_tuple = ("python",)
# print(type(init_tuple))
# ----------------------------------------------------------------------------------

# init_tuple = (1,) * 3
# init_tuple[0] = 2
# print(init_tuple)

# ----------------------------------------------------------------------------------

# init_tuple = ((1,2),) * 7
# print(len(init_tuple[3:8]))

# ----------------------------------------------------------------------------------
# names = [4,2,5,6,8,2]
# for i in names:
#     print(i)

# ----------------------------------------------------------------------------------
# A = [4,0,2,5,0,1]
# for i in A:
#     if i == 0:
#         A.remove(i)
#         A.append(i)
# print(A)

# ----------------------------------------------------------------------------------
# A = [1,2,2,3,4,4,5]
# newlist = []
# for i in A :
#     if i not in newlist:
#          newlist.append(i)
# print(newlist)

# ----------------------------------------------------------------------------------

# A = [1,2,3]
# B = [2,3,4]
# C = [3,4,5]

# for i in A:
#     if i in B and i in C:
#         print(i)

# ----------------------------------------------------------------------------------

# n = int(input("enter the vlue of array"))
# arr = []
# for i in range(n):
#     val = int(input("enter the vlue of array"))
#     arr.append(val)
# sum = 0
# print(arr)
# for i in range(n):
#     if i+1 in range(n):
#         sum += abs(arr[i]- arr[i+1])
# print(sum)

# ----------------------------------------------------------------------------------

# for i in range(1,5):
#     if i == 3:
#         break
#     print(i)
    
# ----------------------------------------------------------------------------------
# for i in range(1,5):
#     if i == 3:
#         continue
#     print(i)

# ----------------------------------------------------------------------------------

# for i in range(1,6):
#     if i == 2:
#         continue
#     print(i)

# ----------------------------------------------------------------------------------

#zip() inside we can take multiple range function
# for i, j in zip(range(1,6), range(5,0,-1)):
#     if i == 3 and j == 3:
#         continue
#     print(i," ",j)

# ----------------------------------------------------------------------------------

#wap to move *

# A = ("prashant*is*a*good*programmer")
# B = ""
# val = ''
# for i in A:
#     if i != "*":
#         B = B + i
#     else:
#         val = val + i
        
# print(B)
# print(val+B)
        
# ----------------------------------------------------------------------------------

#BODMAS
# a = 50
# b = 30
# c = 20
# d = 10
# print((a+b)*c/d)
# print((a-b)*(c/d))
# print(a+(b*c)/d)

# ----------------------------------------------------------------------------------

# x=['A','B','C']
# y=['A','B','C']
# z=[1,2,3,4]
# print(x==y)
# print(x==z)
# print(x != z)

# ----------------------------------------------------------------------------------

# wap to check if two strings are anagrams by using sort function
# A = "listen"
# B = "silent"
# if sorted(A) == sorted(B):
#     print("anagram")
# else:
#     print("not anagram")

# ----------------------------------------------------------------------------------

#wap to count the words in a string

# A = "this is a sentence"

# words = A.split()
# print(len(words))

# A = "this is a sentence"
# count = 1
# for i in A:
#     if i == '':
#         count+=1
# print(count)

# ----------------------------------------------------------------------------------

# given an array, return an array where each element is the product of all the elements in the array axcept itself



