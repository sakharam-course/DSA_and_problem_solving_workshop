# math = 50
# chem = 50
# phy = 50
# hindi = 40
# print(id(math))
# print(id(chem))
# print(id(phy))
# print(id(hindi)) 
# interpreter will crerate only one memory for the value 50 and allocate the same memory address to all the variables which have the value 50.while the hindi subject gets the another memory address.



# list = [[1,2,3],
#         [4,5,6],
#         [7,8,9]]
# print(list[1][1])

# print(2+2) #accepts as a string value.
# print("2"+"2")
# val1 = int(input("enter the val1:"))
# val2 = int(input("enter the val2:"))
# print(val1+val2)  
# # input func. by default accept string values.so we have to do type casting using int data type.

# #int used to convert in integer data type.
# print(int(3.14)) # it will convert the float value into integer value by removing the decimal part.
# # print(int(3+5j)) # error it will give error because complex number cannot be converted into integer.
# print(int("50")) # it will convert the string value into integer value if the string is in numeric form otherwise it will give error.
# # print(int("50.5")) # it will give error because the string value is in float form and it cannot be converted into integer value.
# print(int(True)) # it will convert the boolean value into integer value where True is converted into 1 and False is converted into 0.
# print(int(False)) # it will convert the boolean value into integer value where True is converted into 1 and False is converted into 0.
# # print(int("prashant")) # it will give error because the string value is not in numeric form and it cannot be converted into integer value.
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------

# # float used to convert
# print(float(3)) # it will convert the integer value into float value by adding the decimal part as .0
# # print(float(3+5j)) # it will not convert the complex number into float value.
# print(float("50")) # it will convert the string value into float value if the string is in numeric form otherwise it will give error.
# print(float(True)) # it will convert the boolean value into float value where True is converted into 1.0 and False is converted into 0.0.
# print(float(4.22)) # it will convert the float value into float


# # complex used to convert
# print(complex(3))
# print(complex(3.14))
# print(complex("50"))
# print(complex(True))
# print(complex(3, 4))
# print(complex(True,False))
# # print(complex("name")) # it will give error because the string value is not in numeric form and it cannot be converted into complex value.

# # bool used to convert
#  print(bool(0)) # it will convert the integer value into boolean value where 0 is converted into False and any non zero value is converted into True.
# print(bool(15))
# print(bool(3.14))
# print(bool(1+2j))
# print(bool())  # false
# print(bool(True))
# print(bool(False))
# print(bool(-5))
# print(bool(0.0))
# print(bool("prashant"))