#Wap to accept any one no. and check pos, neg or zero.

# no = int(input("enter the number:"))
# if no > 0:
#     print("the number is positive")
# if no < 0:
#     print("the number is negative")
# if no == 0:
#     print("the number is zero")

# -----------------------------------------------------------------------

# wap to accept 5 numbers and find the greatest number among them.

# a = int(input("enter the num1:"))
# b = int(input("enter the num2:"))
# c = int(input("enter the num3:"))
# d = int(input("enter the num4:"))
# e = int(input("enter the num5:"))
# if a > b and a > c and a > d and a > e:
#     print("the greatest number is:",a)
# if b > a and b > c and b > d and b > e:
#     print("the greatest number is:",b)
# if c > a and c > b and c > d and c > e:
#     print("the greatest number is:",c)
# if d > a and d > b and d > c and d > e:
#     print("the greatest number is:",d)
# if e > a and e > b and e > c and e > d:
#     print("the greatest number is:",e)

# ------------------------------------------------------------------------

# username = input("enter the username:")
# password = input("enter the password:")
# if username == password:
#     print("login successful")
# else:
#     print("invalid credential")

# --------------------------------------------------------------------------

#wap a program to accept phy chem and maths marks calculate total and percentage and if percentage is greater than equal to 60 and gender is equal to male so he is eligible for placement else eligiblefor data entry job.

# phy = int(input("enter the phy marks:"))
# chem = int(input("enter the chem marks:"))
# maths = int(input("enter the maths marks:"))
# gender = input("enter the gender :")
# total = phy + chem + maths
# percentage = (total/3.0)
# print("total marks is:",total)
# print("percentage is:",percentage)
# if percentage >= 60 and gender == "male":
#     print("he is eligible for placement") 
# else:
#     print("he is eligible for data entry job")

# -------------------------------------------------------------------------

#wap to accept a,b,c and find max value

# a = int(input("enter the value of a:"))
# b = int(input("enter the value of b:"))
# c = int(input("enter the value of c:"))
# if a > b :
#     if a > c:
#         print("the max value is:",a)
#     else:
#         print("the max value is:",c)
# else:
#     if b > c :
#         print("the max value is:",b)
#     else:
#         print("the max value is:",c)

# --------------------------------------------------------------------------

#wap to accept day and find if it is weekday or weekend.

# day = input("enter the day:")
# if day == "saturday" or day == "sunday":
#     print("it is weekend")
# else:
#     print("it is weekday")

# -------------------------------------------------------------------------

#wap to accept character , digit, special character and find the type of the character.

# char = ord(input("enter the character:"))    #ord is used for converting char to ascii code
# if char >= 48 and char <= 57:
#     print("it is a digit")
# elif char >= 65 and char <= 90:
#     print("it is an uppercase letter")
# elif char >= 97 and char <= 122:
#     print("it is a lowercase letter")
# else:
#     print("it is a special character")

# ---------------------------------------------------------------------------------------------------------

#wap for change calculation with 

amount = int(input("enter the amount:"))
print (" 100 notes = ",amount//100)
print (" 50 notes = ",(amount%100)//50)
print (" 20 notes = ",((amount%100)%50)//20)
print (" 10 notes = ",(((amount%100)%50)%20)//10)
print (" 5 notes = ",((((amount%100)%50)%20)%10)//5)
print (" 1 notes = ",(((((amount%100)%50)%20)%10)%5)//1)



