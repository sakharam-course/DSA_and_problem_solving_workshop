math = 50
name = "prashant"
pi = 3.14
result = True
# print(type(math))
# print(type(name))
# print(type(pi))
# print(type(result))      # type function is use to get the class name of any variable

# print(id(math))
# print(id(name))
# print(id(pi))
# print(id(result))        # id function is used for the address of the variable

