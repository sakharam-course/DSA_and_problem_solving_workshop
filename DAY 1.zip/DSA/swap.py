# # swap using three variables
# # val1 = 2
# # val2 = 3
# val1 = int(input("enter the val1:")) #100
# val2 = int(input("enter the val2:")) #200
# print("before swapping val1=",val1, "val2=",val2)
# temp = val1 #temp = 100
# val1 = val2 #val1 = 200
# val2 = temp #val2 = 100 
# print("after swapping val1=",val1, "val2=",val2)
# print("value of val1 is:",val1)
# print("value of val2 is:",val2)

# -------------------------------------------------------------------

# # swap using two variables
# val1 = int(input("enter the val1:")) #100
# val2 = int(input("enter the val2:")) #200
# print("before swapping val1=",val1, "val2=",val2)
# val1 = val1 + val2 #val1 = 300
# val2 = val1 - val2 #val2 = 100
# val1 = val1 - val2 #val1 = 200
# print("after swapping val1=",val1, "val2=",val2)
# print("value of val1 is:",val1)
# print("value of val2 is:",val2)

# --------------------------------------------------------------------

# # total marks
# p1 = int(input("enter the p1:")) 
# p2 = int(input("enter the p2:"))
# p3 = int(input("enter the p3:"))
# total = p1 + p2 + p3
# percentage = (total/3.0)
# print("total = ",total)
# print("percentage = ",percentage)

# ----------------------------------------------------------------------

# interest calculator
# p_amount = int(input("enter the principal amount:")) #100000
# roi = int(input("enter the rate of interest:")) #10
# time = int(input("enter the time:")) #1
# si = (p_amount * roi * time)/100
# print("simple interest = ",si)

# ---------------------------------------------------------------------

# height into cm and feet
# height = float(input("enter the height in feet:")) 
# inch = height * 12
# cm = inch * 2.54
# print("height in inch is:",inch)
# print("height in cm is:",cm)

# --------------------------------------------------------------------------

# reverse of a number
# num = 123
# a = num % 10 #3
# num = num // 10 #12
# b = num % 10 #2
# num = num // 10 #1
# c = num % 10 #1
# rev = a*100 + b*10 + c*1
# print("reverse of the number is:",rev)

# n = 123456
# a = n % 10 
# n = n // 10
# b = n % 10
# n = n // 10
# c = n % 10
# n = n // 10
# d = n % 10
# n = n // 10
# e = n % 10
# n = n // 10
# f = n % 10
# rev = a*100000 + b*10000 + c*1000 + d*100 + e*10 + f*1
# print("reverse of the number is:",rev)

# --------------------------------------------------------------------

# # identity operator
# a = 10
# b = 10
# print(a is b) #True
# print(a is not b) #False

# -----------------------------------------------------------------------

#  membership operator
# name ="uttam"
# print("t" in name) #True
# print("z" in name) #False
# print("t" not in name) #False

# ------------------------------------------------------------------------





