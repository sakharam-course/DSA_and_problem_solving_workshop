# wap to reverse a list

# A = [1,2,3,4,5]
# B = []
# for i in range(len(A)-1,-1,-1):
#     B.append(A[i])
# print(B)
# --------------------------------------------------------------

# wap to check if the list is a palindrome

# A = [1,2,3,4,5] 

# print(A)

# print(A[::-1])
# if A == A[::-1]:
#     print("the list is palindrome")
# else:
#     print("the list is not palindrome")

# --------------------------------------------------------------

