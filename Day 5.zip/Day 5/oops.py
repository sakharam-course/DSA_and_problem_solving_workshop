# class in python

# class Student :   #first letter should be caapital
    
#     roll_no = 101
#     def studentData(self): #method/ member function
#         print("student information")
        
# obj = Student()
# print(obj.roll_no)
# obj.studentData()

# --------------------------------------------------------------

# constructor  (__init__ for initializing memory for the parameter)
# class Demo:
#     def __init__(self):
#         print("i am a constructor")
    
#     def msg(self):
#         print("Hello Class")
        
# obj1 = Demo()
# # print(obj) constructor will be called only one time for each object
# obj2 = Demo()
# obj1.msg()

# --------------------------------------------------------------

# class hod:
#     def __init__(self):
#         self.name = "prashant"
#         self.age = 21
#         self.empid = 1001
#     def info(self):
#         print("My name is : ",self.name)
#         print("My age is : ",self.age)
#         print("My empid is : ",self.empid)
        
# obj = hod()
# obj.info()

# --------------------------------------------------------------

# class hod:
#     def __init__(self,name,age,empid):    #parameterize constructor
#         self.name = name
#         self.age = age
#         self.empid = empid
#     def info(self):
#         print("My name is : ",self.name)
#         print("My age is : ",self.age)
#         print("My empid is : ",self.empid)
        
# obj = hod("prashant",21,1001)
# obj.info()

# --------------------------------------------------------------

# class  New:
#     def __init__(self):
#         self.a = 10

# obj1 = New()
# obj2 = New()
# obj3 = New()
# print(obj1.a)
# print(obj2.a)      
# print(obj3.a)
# obj1.a = 20
# print()
# print(obj1.a)
# print(obj2.a)      
# print(obj3.a)

# --------------------------------------------------------------

# declaring instanve variable outside a class by using object

# class Student:    #define Class
#     def __init__(self):    # constructor 
#         self.s_name = "prashant"   #declaring variable 
#         self.s_rollno = 101  # declaring a instance variable inside a constructor
    
#     def getdata(self):
#         self.s_mb = 9999999999  # declaring a instance variable inside a instance method

# obj = Student()   #if the obj is called then constructor will be called
# obj.getdata()     
# del obj.s_mb  #deleting the instanve var using obj
# obj.s_branch = "CSE"   #adding instance avribale by using obj
# print(obj.__dict__)

# --------------------------------------------------------------

# class New:
#     a =  10 #static variable
    
#     def __init__(self):
#         self.name = "prashant"  #instance variable
        
# obj1 = New()
# obj2 = New()
# obj3 = New()  
# print(obj1.a)
# print(obj2.a)
# print(obj3.a) 
# New.a = 50
# print(obj1.a)
# print(obj2.a)
# print(obj3.a)

# --------------------------------------------------------------

# perform create, read, update, delete

# import sys

# class CRUD:
#     def __init__(self):
#         print("student management system")
#         self.studentID = []
#         self.studentName = []
#         self.studentRollno = []
#         self.studentCity = []
    
#     def addStudent(self): 
#         self.studentID.append(input("Enter student ID : "))
#         self.studentName.append(input("Enter student Name : "))
#         self.studentRollno.append(input("Enter student Rollno : "))
#         self.studentCity.append(input("Enter student City: "))
        
#     def showStudent(self):
#         if not self.studentID:
#             print("\nNo records found.")
#             return
        
#         for i in range(len(self.studentID)):
#             print(f"\n[{i+1}] ID: {self.studentID[i]}")
#             print(f"    Name: {self.studentName[i]}")
#             print(f"    Roll No: {self.studentRollno[i]}")
#             print(f"    City: {self.studentCity[i]}")
    
#     def updateStudent(self):
#         id = int(input("Enter student ID to update:"))
#         if id in self.studentID:
#             index = self.studentID.index(id)
#             self.studentName[index] = input("Enter new name: ")
#             self.studentRollNo[index] = int(input("Enter new roll number: "))
#             self.studentCity[index] = input("Enter new city: ")
#         else:
#             print("Student ID not found.")       
    
#     def deleteStudent(self):
#         id = int(input("Enter student ID to delete:"))
#         if id in self.studentID:
#             index = self.studentID.index(id)
#             del self.studentID[index]
#             del self.studentName[index]
#             del self.studentRollNo[index]
#             del self.studentCity[index]
#         else:
#             print("Student ID not found.")
# crud = CRUD()

# while True:
#         print("1.addStudent")
#         print("2.showStudent")
#         print("3. Update Student")
#         print("4. Delete Student")
#         print("5.Exit")
#         choice = int(input("Enter your choice : "))
#         if choice == 1:
#             crud.addStudent()
#         elif choice == 2:
#             crud.showStudent()
#         elif choice == 3:
#             crud.updateStudent()
#         elif choice == 4:
#             crud.deleteStudent()
#         elif choice == 3:
#             sys.exit()
#         else:
#             print("Invalid choice")

# --------------------------------------------------------------

#instance method

# class Student:
#     def __init__(self, name, rollno, mb):
#         self.name = name  #instance variable32
#         self.rollno = rollno
#         self.mb = mb

#     def display(self):   #instance method
#         print(self.name," ",self.rollno," ",self.mb)
    
# stud = Student("prashant",101,9999999999)
# stud.display()

# --------------------------------------------------------------

# static method

# class student:
#     # by using class name we can access static method 
#     @staticmethod
#     def get_personal_detail(firstname,lastname):
#         print("your personal details = ",firstname,lastname)
        
#     @staticmethod
#     def contact_detail(mobile_no,roll_no):
#         print("your college details = ",mobile_no,roll_no)
        
# student.get_personal_detail("prashant","kumar")
# student.contact_detail(9999999999,101)

# --------------------------------------------------------------
# inheritance

# base class : a class which inherits its property to another is called base class or parent class
# derived class : a class which properties are inherited called as derived class or child class

# types of inheritance
# 1. single inheritance
# 2. multiple inheritance
# 3. multilevel inheritance

# single level inheritance

# class College:   #parent class
#     def college_name(self):   #member function of college
#         print("Modern college")
        
# class Student(College):  #child class
#     def student_info(self):  #member function
#         print("Name: prashant")
#         print("Branch: CSE")
        
# obj = Student()  #object created child clas
# obj.college_name()
# obj.student_info()

# --------------------------------------------------------------
#multilevel inheritance

# class College:   #parent class
#     def college_name(self):   #member function of college
#         print("Modern college")
        
# class Student(College):  #child class
#     def student_info(self):  #member function
#         print("Name: prashant")
#         print("Branch: CSE")
    
# class Exam(Student):
#     def subject(self):
#         print("subject: python")
#         print("subject: java")
#         print("subject: cpp")
# obj = Exam()  #object created child clas
# obj.college_name()
# obj.student_info()
# obj.subject()

# --------------------------------------------------------------

#multiple inheritance

# class SubjMarks: #class - 1
#     math = int(input("Enter math marks : "))
#     DE = int(input("Enter DE marks : "))
#     c = int(input("Enter c marks : "))
#     english = int(input("Enter english marks : "))
    
# class PractMarks: #class - 2
#     cpract = int(input("Enter practicals marks of c language: "))
    
# class Result(SubjMarks, PractMarks): #child class
#     #print("if student pass in both = subject and practical paper than pass")
#     def total(self):
#         if self.math >= 40 and self.DE >= 40 and self.c >= 40 and self.english >= 40 and self.cpract >= 40:
#             print("pass")
#         else:
#             print("fail")
# obj = Result()
# obj.total()

# --------------------------------------------------------------

#polymorphism example
# class Principal:
#     def role(self):
#         print("i am managing all activity")

# class Dean:
#     def role(self):
#         print("Dean = i am decision taking person")
    
# class HOD:
#     def role(self):
#         print("hod = i have resposibility of teachers and students")
        
# class Faculty:
#     def role(self):
#         print("faculty = i have to complete syllabus successfully")
# # =========================class declaration completed=========================        
# def func(obj):   # called func obj = 1: Dean
#     obj.role()
# campus = [Principal(),Dean(),HOD(),Faculty()]
# for obj in campus:
#     func(obj)

# --------------------------------------------------------------
# python does not support method overloading and constructor overloading

# class Arithmetic:
#     def add(self,a):
#         print(a)
#     def add(self,a,b):
#         print(a+b)
#     def add(self,a,b,c):
#         print(a+b+c)

# obj = Arithmetic()
# obj.add(10)
# obj.add(10,20)
# obj.add(1,2,3)   #gives error

# --------------------------------------------------------------
# class Arithmetic:
#     def add(self,a=None,b=None,c=None):
#       if a!=None and b==None and c==None:
#         print(a)
#       elif a!=None and b!=None and c==None:
#         print(a+b)
#       elif a!=None and b!=None and c!=None:
#         print(a+b+c)
#       else:
#         print("invalid")
# obj = Arithmetic()
# obj.add(10)
# obj.add(10,20)
# obj.add(1,2,3)

# --------------------------------------------------------------
# class Arithmetic:
#     def __init__(self):
#         print("there is no argument")                       #error
#     def __init__(self,a):
#         print("passing one argument")
#     def __init__(self,a,b):
#         print("passing two argument")
        
# obj = Arithmetic()
# obj = Arithmetic(10)
# obj = Arithmetic(10,20)

# --------------------------------------------------------------

#python supports overiding 
# types = method, constructor overiding

# class Rbi:
#     def home_loan(self):
#         print("home loan = 7.5")
    
#     def car_loan(self):
#         print("car loan = 8%")
    
# class Sbi(Rbi):
#     def home_loan(self):
#         print("Sbi provide home loan = 6.5")
#         super().home_loan()  #using super method your can access parent class method in child class.
        
# obj = Sbi()
# obj.home_loan()   #child class method override the parent class method

# --------------------------------------------------------------

#constructor overiding

# class Father:
#     def __init__(self):
#         print("father: i am already at the breakfat table")
        
# class Child(Father):
#     def __init__(self):
#         print("child: i will be late for breakfast")
#         super().__init__()    #using super method your can access parent class method in child class.
        
# obj = Child()   #child class method override the parent class method

# --------------------------------------------------------------



