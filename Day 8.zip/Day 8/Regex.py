# Regular expressions:
# it is used to develop the digital circuit 
# used to develop the compiler and interpreter
# used to develop the communication protocol like TCP/IP etc.
# used to develop validation logic
# used to develop the pattern matching and searching application like ctrl + f 
# the engine is written in C-Language
# this engine execute and write the re module 

# Compile() Function
# this function available inside re module and this function used to compile the pattern into regular expression object and which have various methods , 
# which execute various operation like

# -------------------------------------------------------------------------------------------------------------------------------------------
# import re  # re module for performing all the regular expression based operation  
# count=0    # to count the number of matching found  
# pattern = re.compile("function")# string converts into bytecode  
# # print(pattern)  
# matcher = pattern.finditer("A function in python is defined by a def statement. python The general syntax looks like this: def function name(Parameter list): statements, i.e. the function body. The parameter python list consists of none or more parameters. ")  
# #print(matcher)  
# for i in matcher:   
#     count+=1   
#     print(i.start(),"...",i.end(),"...",i.group())  
# print("The number of occurrences: ",count)  

# ---------------------------------------------------------------------------------------------------------------------------------------

# import re
# count = 0
# matcher = re.finditer("Hi","HiHiHiHi")
# # print matcher
# for i in matcher:    # loop 4 times execute HiHiHiHi
#     count += 1
#     print(i.start(),"...",i.end(),"...",i.group())
# print("The number of occurrences: ",count)

# -----------------------------------------------------------------------------------------------------------------------------------------------------
# import re
# obj = input("Enter the character: ")
# objmatch = re.finditer(obj,"a7b @k9z")
# # print(objmatch)
# for match in objmatch:
#     print(match.start(),"...",match.end(),"...",match.group())

# ---------------------------------------------------------------------------------------------------------------------------------------

# it always match the beginning of the string
# import re
# a = input("Enter string to perform match operation: ")
# mtch = re.match(a,"python is a programming language")
# print(mtch)
# if mtch != None:
#     print("Match found at beginning levl : " )
#     print(mtch.start(),"...",mtch.end())
# else:
#     print("Match not found at beginning level")

# -------------------------------------------------------------------------------------------------------------------------------------------
# as a name suggest when we have to match full string wih the given pattern then we have got the match

#full match
# import re
# a = input("Enter string to perform full match operation: ")
# mtch = re.fullmatch(a,"pythonisvery")
# print(mtch)
# if mtch != None:
#     print("match found : " )
#     print(mtch.start(),"...",mtch.end())
# else:
#     print("there is no matching at beginning level")
# -----------------------------------------------------------------------------------------------------------------------------------------------------------

# search() function = if the match is found anywhere in the string then it return object else it will return None.
# import re
# a = input("Enter string to perform search operation: ")
# mtch = re.search(a,"python sss dynamic lann")
# print(mtch)
# if mtch != None:
#     print(mtch.start(),"...",mtch.end(),"...",mtch.group())
# else:
#     print("Match not found")

# -------------------------------------------------------------------------------------------------------------------------------

# import re
# a = input("enter string:")
# with open("python20.txt", "r", encoding="utf-8", errors="ignore") as f:
#     c = f.read()

#    # define what you want to match
# mtch = re.search(a, c)
# print(mtch)
# if mtch != None:
#     print("match found")
#     print(mtch.start(), mtch.end())
# else:
#     print("match not found")

# --------------------------------------------------------------
# start()- returns starting index 
# group()- returns matching string of the 
# match()- match function used to match the given pattern to starting or beginning of the string. if match is doen then we will get match 
# search()- if the match found anywhere in the string thrn it returns object else it will return None 
# findall()- this function return a list which contatining all matches
# sub()- this function perform substituions or replacement 
#         re.sub(expression,replacement,string) here every match pattern will be replaced by provided replacement

# --------------------------------------------------------------
# findall() function:
# this function return a list which containing all matches

#findall() function
# import re
# mtch = re.findall('[0-9]',"abch3hdh5bk7zq$&*")
# print(mtch)

# --------------------------------------------------------------
# sub() function:substitute
# this function perform substitution or replacement 

# import re
# obj = re.sub('[a-zA-Z]','X','2345 ABCD Fabc deff')
# print(obj)
# --------------------------------------------------------------

# subn() function:
# this function perform substitution and return a tuple which containing new string and number of substitution performed
# it is similar as sub() only one thing if different that it also return number of replacement.

# import re
# obj = re.subn('[0-7]','@','ab3gd6nkl7')
# print(obj)
# print("the string is:", obj[0])
# print("the number of replacement: ", obj[1])

# --------------------------------------------------------------

# wap to check the valid mobile number
# import re
# mo = input("Enter mobile number: ")
# obj = re.fullmatch("[0-9]\d{9}", mo)
# if obj != None:
#     print("valid mobile number")
# else:
#     print("invalid mobile number")

# --------------------------------------------------------------

#wap to check the valid email id
# import re
# s = input("Enter email id: ")
# m = re.fullmatch(r"[\w\.-]+@(gmail\.com|ybit\.ac\.in)", s)
# if m != None:
#     print("valid email id")
# else:
#     print("invalid email id")

# --------------------------------------------------------------
# write a program to check whether the given file exists or not

# import os,sys
# fname = input("Enter file name: ")
# if os.path.isfile(fname):
#     print("file exists",fname)
#     f = open(fname, "r")
# else:
#     print("file not exists",fname)
#     sys.exit(0)
# print("the content of the file is: ")
# data = f.read()
# print(data)