# The first line of the input consists of two space-separatedintegers-days (M) arld products(N representing the davs and the products in the sales record
# # The next M lines consist of N space-separated integers representing the sales revenue receiver from each product e ach day

# rows = int(input("Enter number of rows: "))
# cols = int(input("Enter number of columns: "))

# matrix = []

# for i in range(rows):
#     row = list(map(int, input(f"Enter elements of row {i+1}: ").split()))
#     matrix.append(row)

# print("Biggest number from each row:")

# for row in matrix:
#     print(max(row) , end = " ")

# --------------------------------------------------------------
#w a function to remove leading zero from a list of integers

#WAP to remove only leading zeros from a list of integers using for loop
# s = [0,0,1,2,0,3,0,0,4]
# result = []
# started = False

# for num in s:
#     if num != 0:
#         started = True
#     if started:
#         result.append(num)

# print(s)
# print(result)

# --------------------------------------------------------------
