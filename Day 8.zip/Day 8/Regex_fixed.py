# subn() function:
# this function perform substitution and return a tuple which containing new string and number of substitution performed
# it is similar as sub() only one thing if different that it also return number of replacement.

# import re
# obj = re.subn('[0-7]','@','ab3gd6nkl7')
# print(obj)
# print("the string is:", obj[0])
# print("the number of replacement: ", obj[1])

# --------------------------------------------------------------

# wap to check the valid mobile number
# import re
# mo = input("Enter mobile number: ")
# obj = re.fullmatch("[0-9]\\d{9}", mo)
# if obj != None:
#     print("valid mobile number")
# else:
#     print("invalid mobile number")

# --------------------------------------------------------------

#wap to check the valid email id - FIXED VERSION
# Validates: cs23f031@ybit.ac.in and sakharamsawant90@gmail.com
# import re
# s = input("Enter email id: ")
# m = re.fullmatch(r"[\w\.-]+@(gmail\.com|ybit\.ac\.in)", s)
# if m != None:
#     print("valid email id")
# else:
#     print("invalid email id")

#         re.sub(expression,replacement,string) here every match pattern will be replaced by provided replacement

# --------------------------------------------------------------
# findall() function:
# this function return a list which containing all matches

#findall() function
# import re
# mtch = re.findall('[0-9]',"abch3hdh5bk7zq$&*")
# print(mtch)

# --------------------------------------------------------------
# sub() function:substitute
# this function perform substitution or replacement 

# import re
# obj = re.sub('[a-zA-Z]','X','2345 ABCD Fabc deff')
# print(obj)
# --------------------------------------------------------------
