# mydict = {
#     101: "prashant",
#     102: "ashish",
#     "103" : "mohini",
#     "104" : "trivani",
#     101: "ashish",
#     104: "ashish"
# }
# print(mydict)

# --------------------------------------------------------------

#with the help of the key we have to print values
# a = mydict[102]
# print(a)

# --------------------------------------------------------------
# we will replace old value with new value
# mydict[102]="peter"
# print(mydict)

# --------------------------------------------------------------
# only print values
# for x in mydict.values():
#     print(x)

# --------------------------------------------------------------
# only print key x=0,1

# for x in mydict():
#     print(x)

# --------------------------------------------------------------
#  print keys and values
# for x,y in mydict.items():
#     print(x,y)

# --------------------------------------------------------------

# if i have to add new value pair in my dictionary

# mydict["mobile_no"] = 234567890
# print(mydict)

# --------------------------------------------------------------

# a = {(1,2):1, (2,3):2, (4,5):3}
# print(a[4,5])

# --------------------------------------------------------------

# a = {'a':1, 'b':2}
# print(a['a','b'])

# --------------------------------------------------------------

# arr ={}
# arr[1] = 1  # arr{1:2, '1':2}
# arr['1'] = 2
# arr[1] += 1
# print(arr)

# sum = 0
# for k in arr:
#     sum += arr[k]    #k=0
# print(sum)

# --------------------------------------------------------------
# my_dict = {}
# my_dict[1] = 1
# my_dict['1'] = 2
# my_dict[1.0] = 4

# sum = 0
# for k in my_dict:
#     sum += my_dict[k]
# print(sum)

# --------------------------------------------------------------

# my_dict = {}
# my_dict[(1,2,4)] = 8
# my_dict[(4,2,1)] = 10
# my_dict[(1,2)] = 12
# sum = 0
# for k in my_dict:
#     sum += my_dict[k]
# print(sum)
# print(my_dict)

# --------------------------------------------------------------

# box = {}
# jars = {}
# crates = {}
# box['bicuit'] = 1
# box['cake'] = 3
# jars['jam'] = 4
# crates['box'] = box
# crates['jars'] = jars
# print(len(crates[box]))

# --------------------------------------------------------------

# dict = {'c' : 97, 'a' : 96, 'b': 98}
# for _ in sorted(dict):
#     print(dict[_])

# --------------------------------------------------------------

# rec = {"name" : "python", "age" : "20"}
# r = rec.copy()
# print(id(r) == id(rec))
# print(id(r))
# print(id(rec))

# --------------------------------------------------------------

# rec = {"name": "python", "age" : "20"}
# id1 = id(rec)
# print(id(id1))
# del rec
# rec = {"name": "python", "age" : "20"}
# id2 = id(rec)
# print(id(id2))
# print(id1 == id2)

# --------------------------------------------------------------

# write a function to find key with the minimum value in a dictionary

# mydict = {"X" : 20, "Y": 10, "Z" : 30}

# min_key = (min(mydict, key=mydict.get))
# print(min_key)

# --------------------------------------------------------------

# mydict = {
#     101 : "prashant",
#     "professional": "developer",
#     "empoid": 1001
# }
# mydict.pop(101)    # pop() method remove pair by specific key name
# print(mydict)
