# def msg():    #call function
#     print("hello world")
    
# msg() #calling funtion

# --------------------------------------------------------------

# def arithmetic():
#     a = int(input("enter value of a"))
#     b = int(input("enter value of b"))
#     add = a + b
#     sub = a - b
#     mul = a * b
#     div = a / b
#     return add,sub,mul,div

# print(arithmetic())    
# result = arithmetic()
# print("arithmetic", result)

# --------------------------------------------------------------

#positional arguments
# def login(username, password):
#     if username == password:
#         print('login successfully')
#     else: 
#         print("invalid credential")
# username = input("enter username")
# password = input("enter password")
# login(username,password)

# --------------------------------------------------------------

#keyword  argument
# def login(username, password):
#     if username == password:
#         print('login successfully')
#     else: 
#         print("invalid credential")
        
# login(username= "admin", password= "admin")

# --------------------------------------------------------------

#default argument
# def cityName(city = "goa"):
#     print(city)

# cityName("Delhi")
# cityName("nagpur")
# cityName()

# --------------------------------------------------------------

#variable length argument/ variable number of arguments
# def nameOfCitys(*city):
#     print("city name's =", city)

# nameOfCitys("goa","nagpur","mumbai","pune","nashik")

# --------------------------------------------------------------

# wap to menu driven code

# import sys
# def add():
#     val1 = int(input("enter value of val1: "))
#     val2 = int(input("enter value of val2: "))
#     print("add=",val1+val2)
# def sub():
#     val1 = int(input("enter value of val1: "))
#     val2 = int(input("enter value of val2: "))
#     print("sub=",val1-val2)
# def mul():
#     val1 = int(input("enter value of val1: "))
#     val2 = int(input("enter value of val2: "))
#     print("mul=",val1*val2)
# def div():
#     val1 = int(input("enter value of val1: "))
#     val2 = int(input("enter value of val2: "))
#     print("div=",val1/val2)
# while True:
#     print("1.addition")
#     print("2.subtraction")
#     print("3.multiplication")
#     print("4,division")
#     print("5.exit")
#     choice = int(input("enter your choice: "))
#     if choice == 1:
#         add()
#     elif choice == 2:
#         sub()
#     elif choice == 3:
#         mul()
#     elif choice == 4:
#         div()
#     elif choice == 5:
#         sys.exit()

# --------------------------------------------------------------

#1. rstrip() ==> to remove spaces at right hand sides
#2. lstrip() ==> to remove spaces at left hand sides
#3. strip() ==> to remove spaces both sides

# programming = input("enter your name:")
# p_name = programming.rstrip()
# if p_name == 'python':
#     print(p_name)
# elif p_name == 'java':
#     print(p_name)
# elif p_name == 'cpp':
#     print(p_name)
# else:
#     print("wrong programming name")
    
