# import sys
# class Queue:
#     def __init__(self,queueSize): #parameterized constructor
#         self.queueList = [] #queue created
#         self.queueSize = queueSize
  
#     def isFull(self):
#       if len(self.queueList) == self.queueSize:
#           return True
#       else:
#           return False

#     def Enqueue(self, value):    # add element in Queue from rear end
#         if self.isFull():
#             print("Queue is full")
#         else:
#             self.queueList.append(value)
#         print(self.queueList)

#     def displayqueue(self):
#         print(self.queueList)

#     def isEmpty(self):
#         if self.queueList == []:
#                 return True
#         else:
#                 return False
             
#     def Dequeue(self):
#         if self.isEmpty():
#           return "Queue is empty"
#         else:
#           return self.queueList.pop(0)

#     def deleteQueue(self):
#         self.queueList = []
#         return "Queue is deleted"
   
#     def peek(self):
#         if self.isEmpty():
#             return "Queue is empty"
#         else:
#             return self.queueList[0]   #slicing of list
      
# size = int(input("enter the size of queue :"))
# queueObj = Queue(size)

# while True:
#     print("1. enqueue element in queue :")
#     print("2. display queue element :")
#     print("3.check Queue isempty :")
#     print("4.dequeue operation :")
#     print("5.delete queue :")
#     print("6.peek operation :")
#     print("7. exit")

#     choice = int(input("enter your choice : "))
#     if choice == 1:
#         val = int(input("enter value for queue :"))
#         queueObj.Enqueue(val)

#     elif choice == 2:
#         queueObj.displayqueue()
  
#     elif choice == 3:
#         print(queueObj.isEmpty())

#     elif choice == 4:
#         print(queueObj.Dequeue())
 
#     elif choice == 5:
#         print(queueObj.deleteQueue())

#     elif choice == 6:
#         print(queueObj.peek())
  
#     elif choice == 7:
#         sys.exit()

# --------------------------------------------------------------

#linear seach

# def linearSearch(array,target):   #[1,2,3,4,5,6,7,8,9]  target = 4          =======> O(n)
#     for i in range(len(array)):  #i = 0                                     =======> O(n)
#         if array[i] == target:  #i(1) == 1                                  =======> O(1)
#             return i                                                        =======> O(1)
#     return -1                                                               =======> O(1)


# array = [1,2,3,4,5,6,7,8,9]
# target = 4
# linearSearch(array,target)
# result = linearSearch(array,target)
# if result == -1:
#     print("Not Found")
# else:
#     print(f"Element found at index no: ",result)

# --------------------------------------------------------------

# binary search

# def binarySearch(array,target):   # [1,2,3,4,5,6,7,8,9]  
#     start = 0
#     end = len(array)-1
#     while start <= end:
#         mid = (start + end) // 2
#         if array[mid] == target:
#             return mid
#         elif array[mid] < target:
#             start = mid + 1
#         else:
#             end = mid -1
#     return -1

# sortedArray = [1,2,3,4,5,6,7,8,9]
# target = 55   # 4 we have to find
# result = binarySearch(sortedArray,target)
# if result == -1:
#     print("Not Found")
# else:
#     print(f"Element found at index no: ",result)

# ---------------------------------------------------------------------------------------------------------------
#Linked list

# class Node:
#     def __init__(self, data):
#         self.data = data  #instance var   head = 5->10->15->20->None
#         self.next = None
        
# class LinkedList:
#     def __init__(self):
#         self.head = None
        
# linkedlist = LinkedList()
# linkedlist.head = Node(5)   # first node
# second          = Node(10)  # second node
# third           = Node(15)  # third node
# fourth          = Node(20)  # fourth node
# # linking part
# linkedlist.head.next = second
# second.next = third
# third.next = fourth

# print(linkedlist.head.data)
# print(second.data)
# print(third.data)
# print(fourth.data)

# print(linkedlist.head.next)
# print(second.next)
# print(third.next)
# print(fourth.next)

# #display linkedlist
# while linkedlist.head != None:
#     print("|",linkedlist.head.data,"|","|",linkedlist.head.next,"->", end = " ") 
#     linkedlist.head = linkedlist.head.next

# ------------------------------------------------------------------------------------------------------------

#menu driven program to perform operations on linked list
# import sys

# class Node:
#     def __init__(self,data):
#         self.data= data #instance variable
#         self.next=None

# class Linkedlist:
#     def __init__(self):
#         self.head=None
#         self.tail=None

#     def addnode(self,value):
#         node=Node(value)
#         if self.head==None:
#             self.head=node
#             self.tail=node
#         else:
#             self.tail.next=node
#             self.tail=node
    
#     def addnodebeginning(self,value):
#         node = Node(value)
#         if self.head == None:
#             self.head=node
#             self.tail=node
#         else:
#             node.next=self.head
#             self.head=node

#     def addnodebetween(self,index,value):
#         node = Node(value)
#         if self.head == None:
#             self.head=node
#             self.tail=node
#         elif index==0:
#             node.next = self.head
#             self.head=node
#         else:
#             temp=self.head
#             for _ in range(index-1):
#                 temp=temp.next
#             node.next=temp.next
#             temp.next=node

#     def deletenode(self,index):
#         if index==0:
#             self.head=self.head.next
#         else:
#             temp=self.head
#             for _ in range(index-1):
#                 temp=temp.next
#             temp.next=temp.next.next

#     def displaylinkedlist(self):
#         temp=self.head
#         while temp!=None:
#             print("|",temp.data,"|-->",end="")
#             temp=temp.next
            
            
# if __name__ == '__main__':
#     object=Linkedlist()

#     while True:
#         print()
#         print("Menu Driven Linkedlist")
#         print("1.Add node Linkedlist")
#         print("2.Add Node in Beginning")
#         print("3.Add Node in Between")
#         print("4.Display Linkedlist")
#         print("5.Delete Node")
#         print("6.Exit")

#         choice=int(input("Enter your choice:"))
#         if choice==1:
#             value = int(input("Enter the value for node: "))
#             object.addnode(value)
#             print("Node added successfully in single linkedlist.")
#         elif choice==2:
#             value=int(input("Enter the value for node: "))
#             object.addnodebeginning(value)
#             print("Node added at the beginning")
#         elif choice==3:
#             value=int(input("Enter the value for node: "))
#             index=int(input("Enter the index: "))
#             object.addnodebetween(index,value)
#             print("Node added in between")
#         elif choice==4:
#             print("Elements in the linkedlist are:")
#             object.displaylinkedlist()
#         elif choice==5:
#             index=int(input("Enter the index: "))
#             object.deletenode(index)
#             print("Node",index," deleted successfully")
#         elif choice==6:
#             sys.exit()
#             print("Exiting...") 
#         else:
#             print("Invalid choice")
        
# --------------------------------------------------------------
# import sys 

# class Node:
#     def __init__(self, data):
#         self.data = data
#         self.next = None
        
# class LinkedList:
#     def __init__(self):
#         self.head = None
#         self.tail = None

#     # add node (same as add at end)
#     def addNode(self, value):
#         node = Node(value)
#         if self.head == None:
#             self.head = node
#             self.tail = node
#         else:
#             self.tail.next = node
#             self.tail = node

#     # add node at beginning
#     def addNodeInBeginning(self, value):
#         node = Node(value)
#         if self.head == None:
#             self.head = node
#             self.tail = node
#         else:
#             node.next = self.head
#             self.head = node

#     # add node at end
#     def addNodeInEnd(self, value):
#         self.addNode(value)

#     # add node in between (at given position)
#     def addNodeInBetween(self, value, pos):
#         node = Node(value)

#         # insert at beginning
#         if pos == 1:
#             self.addNodeInBeginning(value)
#             return

#         temp = self.head
#         count = 1

#         while temp is not None and count < pos - 1:
#             temp = temp.next
#             count += 1

#         if temp is None:
#             print("Position out of range")
#             return

#         node.next = temp.next
#         temp.next = node

#         # if inserted at last, update tail
#         if node.next is None:
#             self.tail = node

#     # display linked list
#     def displayLinkedList(self):
#         temp = self.head
#         if temp is None:
#             print("Linked List is empty")
#             return
        
#         while temp:
#             print(temp.data, end=" -> ")
#             temp = temp.next
#         print("None")


# if __name__ == "__main__":
#     obj = LinkedList()
    
#     while True:
#         print("\n1. add node in linkedlist")
#         print("2. add node in beginning")
#         print("3. add node in between")
#         print("4. add node in end")
#         print("5. display linkedlist")
#         print("6. exit")
        
#         choice = int(input("enter your choice : "))
        
#         if choice == 1:
#             val = int(input("enter value for node : "))
#             obj.addNode(val)
#             print("Node added successfully")

#         elif choice == 2:
#             val = int(input("enter value for node : "))
#             obj.addNodeInBeginning(val)
#             print("Node added successfully")

#         elif choice == 3:
#             val = int(input("enter value for node : "))
#             pos = int(input("enter position for node : "))
#             obj.addNodeInBetween(val, pos)
#             print("Node added successfully")

#         elif choice == 4:
#             val = int(input("enter value for node : "))
#             obj.addNodeInEnd(val)
#             print("Node added successfully")

#         elif choice == 5:
#             obj.displayLinkedList()

#         elif choice == 6:
#             break

#         else:
#             print("Invalid choice")