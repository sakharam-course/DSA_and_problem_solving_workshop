# write a function to sort a dictionary  by keys or values in ascending and descending order

# A = {
#     "C" : 3,
#     "B" : 2,
#     "A" : 1
# }
# A = sorted(A.items())
# print(A)
# print(A[::-1])

# --------------------------------------------------------------------------------------------------------------------
#write a program to remove all elements from the dictionary

# A = {
#     "C" : 3,
#     "B" : 2,
#     "A" : 1
# }

# A.clear()
# print(A)

# ----------------------------------------------------------------------------------------------------------------------
# Wap to find biggest number in the array

# def Findbiggestnumber(Array):      
#     firstvalue = Array[0]                   ------------------ O(1) -        O(1)
#     for i in range(1,len(Array)):           ------------------ O(1) - ------ O(n)
#         if Array[i] > firstvalue:           ------------------ O(1) - O(1)
#             firstvalue = Array[i]           ------------------ O(1) -
#     return firstvalue                       

# Array = [1,2,3,4,5,6,99,8,9,10]
# print(Findbiggestnumber(Array))            ------------------ O(1) ---------- O(1) final = O(1) + O(n) + O(1) = O(n)
# -----------------------------------------------------------------------------------------------------------------------

#w an algorithm to help the agency find the number of special characters and whitespaces in a given message.

# def count_specialcharacters_and_whitespaces(message):
#     special_characters_count = 0
#     whitespaces_count = 0
    
#     for char in message:
#         if char.isspace():
#             whitespaces_count += 1
#         elif not char.isalnum():
#             special_characters_count += 1
            
#     return special_characters_count, whitespaces_count

# message = "Hello, World! This is a test message with special characters: @#$%^&*() and whitespaces."
# print(count_specialcharacters_and_whitespaces(message))

# ------------------------------------------------------------------------------------------------------------------------
#write a program to help apparel find the number of plots that it can select for its outlets.

# import math

# list = [79,77,54,81,48,34,25,16]
# count = 0
# for i in list:
#     if math.sqrt(i) == math.sqrt(i)//1:
#         count += 1
# print(count)

# ----------------------------------------------------------------------------------------------------------------------
# specialcharacters
# var='gagg54@#vshjkdls*#""'
# count=0
# for i in var:
#     z=ord(i)
#     if z>=97 and z<=122:
#         continue
#     elif z>=48 and z<=57:
#         continue
#     else:
#         count+=1
# print(count)

# ----------------------------------------------------------------------------------------------------------------------
