# # file creation

# f = open("myfile.txt", "w")
# print("name of file: ", f.name)
# print("file mode: ", f.mode)
# print("readable: ", f.readable())
# print("writable: ", f.writable())
# print("file closed: ", f.closed)
# f.close
# print("file closed: ", f.closed)

# # --------------------------------------------------------------

# # performing write operation
# f = open("myfile.txt", "w")
# f.write("Nagpur is a smart City")
# f.close
# print("file operation completed")

# # --------------------------------------------------------------

# # adding a new line
# f = open("myfile.txt", "a")
# f.write("\nDodamarg is a smart City")
# f.write("\nHyderabad is a smart City")
# f.write("\nPune is a smart City")
# f.write("\nMumbai is a smart City")
# f.write("\nDelhi is a  smart City")
# f.write("\nSawantwadi is a smart City")
# f.close
# print("file operation completed")

# --------------------------------------------------------------

#inserting a list tuple
# f = open("myfile.txt", "w")
# mylist = ["prashant", "jha", "mahesh"]
# mytuple = ("prashant", "jha", "mahesh")
# mydict = {"name": "prashant", "age": 21}

# f.writelines(mylist)
# f.writelines(mytuple)
# f.writelines(mydict)
# f.close
# print("written work has done successfully")

# --------------------------------------------------------------

# reading a file
# f = open("myfile.txt", "r")
# print(f.read())
# f.close

# --------------------------------------------------------------

# with open("myfile.txt", "w") as f:
#     f.write("amit\n")
#     f.write("ashish\n")
#     f.write("prashant\n")
#     print("file closed: ",f.closed)
# print("file closed: ",f.closed)

# --------------------------------------------------------------

# with open("myfile.txt","r") as f:
#     content = f.read()
#     print(content)

# --------------------------------------------------------------

# f1 = open("h.jpeg", "rb")
# f2 = open("sakharam.jpeg", "wb")
# data = f1.read()
# f2.write(data)
# print("new imah=ge is available with the name")

# --------------------------------------------------------------

#operation with csv file

# import csv
# f = open("student.csv", "a", newline = "")
# a = csv.writer(f)
# # a.writerow(["studentID","rollno","name","mobileno"])
# studentid = int(input("enter the studentID:"))
# rollno = int(input("enter the rollno:"))
# name = input("enter the name:")
# mobileno = int(input("enter the mobileno:"))
# a.writerow([studentid,rollno,name,mobileno])
# print("student record has save")


# --------------------------------------------------------------

#write a prohram to take the input rollno name mobileno emailand marks if three subject and calculate total, percentage alsoreturn result as pass or fail if if user subjects marks are 40 above

import csv
f = open("student.csv", "a", newline = "")
a = csv.writer(f)
a.writerow(["studentID","rollno","name","mobileno","email","marks1","marks2","marks3","total","percentage","result"])
studentid = int(input("enter the studentID:"))
rollno = int(input("enter the rollno:"))
name = input("enter the name:")
mobileno = int(input("enter the mobileno:"))
email = input("enter the email:")
marks1 = int(input("enter the marks1:"))
marks2 = int(input("enter the marks2:"))
marks3 = int(input("enter the marks3:"))
percentage = (marks1+marks2+marks3)/3
if percentage >= 40:
    result = "pass"
else:
    result = "fail"
    
a.writerow([studentid,rollno,name,mobileno,email,marks1,marks2,marks3,marks1+marks2+marks3,percentage,result])
print("student record has save")
