# print('prashantjha777'.isalnum())  #isalphanumeric
# print('prashant777'.isalpha())   #isalphabetic
# print('777f'.isdigit())
# print('aaesdsfdf'.islower())
# print(''.islower())
# print('prashantj'.isupper())
# print('my name is prashant'.istitle())
# print(''.istitle())
# print(''.isspace())
# print("hello".startswith("He"))
# print("hello".endswith("lo"))

# ----------------------------------------------------------------------------------------------

# print("Prashant".find("r"))
# print("Prashant".index("r"))
# print("Prashant jha".count("a"))

# ----------------------------------------------------------------------------------------------

# write a function to check if a key exists in a dictionary using the operator or the get() method

# mydict = {"name": "prashant", "age": 21}
# if "age" in mydict:
#     print("key exists")
# else:
#     print("key does not exist")

# ----------------------------------------------------------------------------------------------

#write a function to count the frequency of elements in a list using a dictionary

# mylist = [1,2,3,4,1,2,3,4,1,3,3,4]
# mydict = {}
# for i in mylist:   
#     if i in mydict:  
#         mydict[i] += 1
#     else:
#         mydict[i] = 1
# print(mydict)

#  --------------------------------------------------------------

# write an algorithm to find the security key for the data

# mylist = [5,7,8,3,7,8,9,2,3]
# newlist = []

# for i in range(len(mylist)):
#     count = 0
#     key = mylist[i]
    
#     j = i + 1
#     while j < len(mylist):
#         if key == mylist[j]:
#             newlist.append(key)
#         j += 1
# print(len(newlist))

# --------------------------------------------------------------
    
# find the second largest element

# list = [2,5,4,7,8]
# list.sort()
# print(list)
# print(list[-2])

# --------------------------------------------------------------

# i = 1
# while i <= 5:
#     print(i)
#     i += 1

# --------------------------------------------------------------

# username = ""
# password = ""
# while username != "admin" or password != "admin":
#     username = input("enter username: ")
#     password = input("enter password: ")

# --------------------------------------------------------------

#wap to count vowels and consonants in the string
# name = "programming"
# vowels = ['a','e','i','o','u']
# cons = 0
# vowel = 0
# for i in name:
#     if i in vowels:
#         vowel += 1
#     else:
#         cons += 1
        
# print("vowels",vowel)
# print("consonants",cons) 

# ---------------------------------------------------------------

# write a function to remove all occurences of a specific element in a list

# list = [1,2,2,3,4,2]

# while 2 in list:
#     list.remove(2)
# print(list)

# ---------------------------------------------------------------

# write a function to calculate the product and sum of all elements in a list using a loop

# list = [2,3,4,5]

# P = 1
# S = 0
# for i in list:
#     P = P * i
#     S = S + i
# print(P)
# print(S)

# --------------------------------------------------------------


