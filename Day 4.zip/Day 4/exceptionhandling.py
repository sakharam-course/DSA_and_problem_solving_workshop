
# n1 =  int(input("Enter first value : "))
# n2 =  int(input("Enter second value : "))

# try: 
#     print(n1/n2)
# except ZeroDivisionError:
#     print("cannot divide by zero")
# print("to be continued")

# -----------------------------------------------------------------------------------------------
# try: 
#     n1 =  int(input("Enter first value : "))
#     n2 =  int(input("Enter second value : "))

#     print(n1/n2)
# except ZeroDivisionError:
#     print("cannot divide by zero")
# except ValueError:
#     print("Enter olny integer value")
# print("to be continued")

# -----------------------------------------------------------------------------------------------

# handle multiple kinds of exception with
# single except block

# try: 
#     a =  int(input("Enter first value : "))
#     b =  int(input("Enter second value : "))
#     print(a/b)
# except (ValueError, ZeroDivisionError) as message:
#     print(message)

# --------------------------------------------------------------

# if any third exception is coming at runtime then we can use nested Exception block

# try: 
#     a =  int(input("Enter first value : "))
#     b =  int(input("Enter second value : "))
#     print(a/b)
# except (ValueError, ZeroDivisionError) as message:
#     print("Enter correct number: ",message)
# except:
#     print("this  is default part of except block")

# --------------------------------------------------------------

# we can use else block if no error generate it 

# try: 
#     a =  int(input("Enter first value : "))
#     b =  int(input("Enter second value : "))
#     print(a/b)
# except (ValueError, ZeroDivisionError) as message:
#     print("Enter correct number: ",message)
# else:
#     print("everything is ok")

# --------------------------------------------------------------

# finally block will be executed always whethr try block generate error or not

# try: 
#     a =  int(input("Enter first value : "))
#     b =  int(input("Enter second value : "))
#     print(a/b)
# except (ValueError, ZeroDivisionError) as message:
#     print("Enter correct number: ",message)
# finally:
#     print("this will be always executed")
    
# --------------------------------------------------------------

# nested try except block 
# try:
#     a =  int(input("Enter first value : "))
#     b =  int(input("Enter second value : "))
#     try:
#         print(a/b)
#     except ZeroDivisionError as msg:
#         print(msg)
# except ValueError as msg:
#     print(msg)       

#  --------------------------------------------------------------

# try:
#     a =  int(input("Enter first value : "))
#     b =  int(input("Enter second value : "))
#     print(a/b)
# except (ValueError, ZeroDivisionError) as message:
#     print(message)
# else: 
#     print("there are no error in try block")
# finally:
#     print("i am finally block i will be executed always")  