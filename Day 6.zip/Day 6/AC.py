# abstraction

# from abc import ABC, abstractmethod

# class Help4code(ABC): # Abstract class
#     @abstractmethod   # Decorator
#     def training(self):  #abstract method
#         pass
    
#     def placement(self):
#         pass
    
# class Ashish(Help4code):
#     def training(self):
#         print('C, C++, Java')
#     def placement(self):
#         print("Java Placement")

# class Ankush(Help4code):
#     def training(self):
#         print('Python, Django')
#     def placement(self):
#         print("Python Placements Students")
        
# class Prashant(Help4code):
#     def training(self):
#         print('Machine Learning')
#     def placement(self):
#         print("Data Science Students")
        
# obj1 = Ashish()
# obj1.training()
# obj1.placement()

# obj2 = Ankush()
# obj2.training()
# obj2.placement()

# obj3 = Prashant()
# obj3.training()
# obj3.placement()

# --------------------------------------------------------------

# from abc import ABC, abstractmethod

# class Irctc(ABC): # Abstract class
#     @abstractmethod   # Decorator
#     def bookTicket(self):  #abstract method
#         pass
    
# class MakeMyTrip(Irctc):
#     def bookTicket(self):
#         print("=====================================")
#         print("welcome to MakeMyTrip")
#         source = input("Enter source station name: ")
#         destination = input("Enter destination station name: ")
#         date = input("Enter date: ")
#         print("=====================================")
# class GoIbibo(Irctc):
#     def bookTicket(self):
#         print("=====================================")
#         print("welcome to GoIbibo")
#         source = input("Enter source station name: ")
#         destination = input("Enter destination station name: ")
#         date = input("Enter date: ")
#         print("=====================================")
        
# class Yatra(Irctc):
#     def bookTicket(self):
#         print("=====================================")
#         print("welcome to Yatra.com")
#         source = input("Enter source station name: ")
#         destination = input("Enter destination station name: ")
#         date = input("Enter date: ")
#         print("=====================================")
        
# obj1 = MakeMyTrip()
# obj1.bookTicket()

# obj2 = GoIbibo()
# obj2.bookTicket()

# obj3 = Yatra()
# obj3.bookTicket()

# --------------------------------------------------------------

#Encapsulation

# class Base:         #parent class
#     def __init__(self):
#         print("Parent class constructor called")
#         self.a = "Prashant"  # public data member
#         self.__c = "Ashish"  # private data member
# # creating a derived class / child class
# class Derived(Base):
#     def __init__(self):
#         # calling constructor of base class
#         Base.__init__(self)
#         # print ("calling private member of base class:")
#         # print(self.a)
#         # print(self.__c)
# # obj1 = Derived()
# # print(obj1.a)
# # print(obj1.__c)

# obj2 = Base()
# print(obj2.a)  # Accessible
# print(obj2.__c)  # not Accessible

# --------------------------------------------------------------

# class Rbi:
#     #delcaring public method
#     def publicPolicy(self):
#         print("check the public policy of rbi")
#     #declaring private method   
#     def __privatePolicy(self):
#         print("there is some private policy which is not accessible for public")
        
# class Sbi(Rbi):
#     def __init__(self):  #first sbi class const called
#         Rbi.__init__(self)  #second rbi class const called
    
#     def callingPublicMethod(self):  # child class public method
#         print("\n Inside child class")
#         self.publicPolicy() # calling parent class public method
        
#     def callingPrivateMethod(self):  #child class private method
#         print("\n Inside child class")
#         self.__privatePolicy()  # calling parent class private method
        

# # obj1 = Sbi()
# # obj1.callingPublicMethod()
# # obj1.callingPrivateMethod()
# # obj1.publicPolicy()
# # obj1.__privatePolicy()

# # obj2 = Rbi()
# # obj2.publicPolicy()
# # obj2.__privatePolicy()     ## private policy are accessible inside class only
# obj2 = Rbi()
# obj2.publicPolicy()
# obj2._Rbi__privatePolicy()

