# import sys
# class Stack:
#     def __init__(self):
#         self.stacklist=[]

#     def push(self,value):
#         self.stacklist.append(value)

#     def display(self):
#         print("---------------------------")
#         print(self.stacklist)
#         print("---------------------------")

#     def isEmpty(self):
#         if self.stacklist==[]:
#             return True
#         else:
#             return False
    
#     def pop(self):
#         if self.isEmpty():
#             return "stack is empty"
#         else:
#             return self.stacklist.pop()
        
#     def delete(self):
#         self.stacklist=None
#         print("stack is deleted")

#     def peek(self):
#         if self.isEmpty():
#             return "stack is empty"
#         else:
#             return self.stacklist[-1]
        


# stackobj=Stack()

# while True:
    
#     print("1.push element")
#     print("2.display stack element")
#     print("3. check isEmpty")
#     print("4.pop element")
#     print("5.delete stack")
#     print("6.peek operation")
#     print("7.Exit")



#     choice = int(input("enter your choice:"))
#     if choice ==1 :
#         val= int(input("enter the value for stack:"))
#         stackobj.push(val)

#     elif choice == 2:
#         stackobj.display()
    
#     elif choice == 3:
#        print(stackobj.isEmpty())
    
#     elif choice == 4:
#         print(stackobj.pop())

#     elif choice==5:
#         stackobj.delete()

#     elif choice==6:
#         stackobj.peek()
    
#     elif choice==7:
#         sys.exit()
#     else:
#             print("Invalid choice, please try again.")


# -----------------------------------------------------------------------------------------------



# import sys
# class Stack:
#     def __init__(self, stackSize):
#         self.stacklist = []
#         self.stackSize = stackSize
        
#     def isFull(self):
#         if len(self.stacklist) == self.stackSize:
#             return True
#         else:
#             return False

#     def push(self,value):
#         if self.isFull():
#             print("stack is full")
#         else:
#             self.stacklist.append(value)

#     def display(self):
#         print("---------------------------")
#         print(self.stacklist)
#         print("---------------------------")

#     def isEmpty(self):
#         if self.stacklist == []:
#             return True
#         else:
#             return False
    
#     def pop(self):
#         if self.isEmpty():
#             return "stack is empty"
#         else:
#             return self.stacklist.pop()
        
#     def delete(self):
#         self.stacklist = None
#         print("stack is deleted")

#     def peek(self):
#         if self.isEmpty():
#             return "stack is empty"
#         else:
#             return self.stacklist[-1]
        

# size = int(input("Enter the size of the stack: "))
# stackobj =  Stack(size)

# while True:
    
#     print("1.push element")
#     print("2.display stack element")
#     print("3. check isEmpty")
#     print("4.pop element")
#     print("5.delete stack")
#     print("6.peek operation")
#     print("7.Exit")



#     choice = int(input("enter your choice:"))
#     if choice == 1 :
#         val= int(input("enter the value for stack:"))
#         stackobj.push(val)

#     elif choice == 2:
#         stackobj.display()
    
#     elif choice == 3:
#        print(stackobj.isEmpty())
    
#     elif choice == 4:
#         print(stackobj.pop())

#     elif choice == 5:
#         stackobj.delete()

#     elif choice == 6:
#         stackobj.peek()
    
#     elif choice == 7:
#         sys.exit()
#     else:
#             print("Invalid choice, please try again.")

# ----------------------------------------------------------------------------------------

# Tower of hanoi

#   Rules 
#  1. we can move only one disk at a time
#  2. we have to pick upper disk from any one pipe 
#  3. we have to place on top of any disk 
#  4. we can not place any large disk on top of samller disk

#WAP FOR TOWER OF HANOI PROBLEM

# def towerOfHanoi(n , from_rod, to_rod, aux_rod): 
#     if n == 1: 
#         print("Move disk 1 from rod",from_rod,"to rod",to_rod) 
#         return
#     towerOfHanoi(n-1, from_rod, aux_rod, to_rod) 
#     print("Move disk",n,"from rod",from_rod,"to rod",to_rod) 
#     towerOfHanoi(n-1, aux_rod, to_rod, from_rod)

# n = 4
# towerOfHanoi(n, 'A', 'C', 'B')

# --------------------------------------------------------------


#WAP FOR TOWER OF HANOI PROBLEM
# import time

# class TowerOfHanoi:
#     def __init__(self, source):
#         self.A = source[:]   # source
#         self.B = []          # auxiliary
#         self.C = []          # destination
#         self.n = len(source)

#     def display(self):
#         print(f"A: {self.A}   B: {self.B}   C: {self.C}")
#         print("-" * 40)
#         time.sleep(1)  # delay (1 second)

#     def move_disk(self, from_rod, to_rod, from_name, to_name):
#         if not from_rod:
#             disk = to_rod.pop()
#             from_rod.append(disk)
#             print(f"Move disk {disk} from {to_name} → {from_name}")
#         elif not to_rod:
#             disk = from_rod.pop()
#             to_rod.append(disk)
#             print(f"Move disk {disk} from {from_name} → {to_name}")
#         elif from_rod[-1] > to_rod[-1]:
#             disk = to_rod.pop()
#             from_rod.append(disk)
#             print(f"Move disk {disk} from {to_name} → {from_name}")
#         else:
#             disk = from_rod.pop()
#             to_rod.append(disk)
#             print(f"Move disk {disk} from {from_name} → {to_name}")

#         self.display()  # show state after every move

#     def solve(self):
#         print("Initial State:")
#         self.display()

#         s, a, d = 'A', 'B', 'C'

#         if self.n % 2 == 0:
#             a, d = d, a

#         total_moves = 2 ** self.n - 1

#         for i in range(1, total_moves + 1):
#             if i % 3 == 1:
#                 self.move_disk(self.A, self.C, s, d)
#             elif i % 3 == 2:
#                 self.move_disk(self.A, self.B, s, a)
#             else:
#                 self.move_disk(self.B, self.C, a, d)

#         print("Final State:")
#         self.display()


# --------------------------------------------------------------
# import time
# class Tower:
#     def __init__(self):
#         print("Tower of Hanoi")
#         print()
#         print("given problem   A=[3,2,1], B = [], C = []")
#         print()
#         print("expected output A =[], B =[] , C =[3,2,1]")
#         self.A = []
#         self.B = []
#         self.C = []
#         self.D = []

#     def tower(self,item):
#         self.A.append(item)
#         print("A = ",self.A)
#         print("Items in Tower A\n")

#     def pass1(self):
#         self.temp = self.A.pop(2) #a=[3,2]
#         self.C.append(self.temp) #c = [1] =>temp = 1
#         time.sleep(3)
#         print("A = ",self.A   ,"    ",   "B=",self.B  ,"   ","C=",self.C)
#         print("pass one completed=========================")
        
#     def pass2(self):
#         self.temp = self.A.pop(1)
#         self.B.append(self.temp)
#         time.sleep(3)
#         print("A = ",self.A   ,"    ",   "B=",self.B  ,"   ","C=",self.C)
#         print("pass two completed=========================")
        
#     def pass3(self):
#         self.temp = self.C.pop(0)
#         self.B.append(self.temp)
#         time.sleep(3)
#         print("A = ",self.A   ,"    ",   "B=",self.B  ,"   ","C=",self.C)
#         print("pass three completed=========================")
    
#     def pass4(self):
#         self.temp = self.A.pop(0)
#         self.C.append(self.temp)
#         time.sleep(3)
#         print("A = ",self.A   ,"    ",   "B=",self.B  ,"   ","C=",self.C)
#         print("pass three completed=========================")   
    
#     def pass5(self):
#         self.temp = self.B.pop(0)
#         self.A.append(self.temp)
#         time.sleep(3)
#         print("A = ",self.A   ,"    ",   "B=",self.B  ,"   ","C=",self.C)
#         print("pass three completed=========================")
        
#     def pass6(self):
#         self.temp = self.B.pop(0)
#         self.C.append(self.temp)
#         time.sleep(3)
#         print("A = ",self.A   ,"    ",   "B=",self.B  ,"   ","C=",self.C)
#         print("pass three completed=========================")    
        
#     def pass7(self):
#         self.temp = self.A.pop(0)
#         self.C.append(self.temp)
#         time.sleep(3)
#         print("A = ",self.A   ,"    ",   "B=",self.B  ,"   ","C=",self.C)
#         print("pass three completed=========================")    
         
# obj = Tower()
# obj.tower(3)
# obj.tower(2)
# obj.tower(1)
# obj.pass1()
# obj.pass2()
# obj.pass3()
# obj.pass4()
# obj.pass5()
# obj.pass6()
# obj.pass7()