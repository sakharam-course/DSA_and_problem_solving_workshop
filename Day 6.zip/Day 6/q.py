# wap to reverse each word in string using split function

# str = "Hello World"
# list = str.split()
# print(list)
# new_list = []
# for i in list:
#     new_list.append(i[::-1])
# print(" ".join(new_list))

# --------------------------------------------------------------


# wap a program to compress a string by replacing consectutive characters with their counts

# s = "aaabbbcccc"
# new_str = ""
# count = 1

# for i in range(1, len(s)):
#     if s[i] == s[i-1]:
#         count += 1
#     else:
#         new_str += s[i-1] + str(count)
#         count = 1

# new_str += s[-1] + str(count)

# print(new_str)

# --------------------------------------------------------------

#wap to print N space-seperated integers such that all the odd numbrs of the listcome after the even numbers

# N = 8

# list = [10,98,3,33,12,22,21,11]
# even = []
# odd = []

# for i in list:
#     if i % 2 == 0:
#         even.append(i)
#     else:
#         odd.append(i)
        
# print(even + odd)


