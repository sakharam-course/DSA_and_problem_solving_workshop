# class Tree:
#     def __init__(self,data):
#         self.data = data    # instance var(create seperate memory for each instance of class
#         self.children = []
    
#     def addChild(self,child):
#         self.children.append(child)

#     def __str__(self,level=0):
#         ret = "  " * level + str(self.data) + "\n"
#         for child in self.children:
#             ret+=child.__str__(level+1)   #recursion
#         return ret

# #object creation
# rootNode=Tree("Drinks")
# hot = Tree("Hot")
# cold = Tree("Cold")
# tea = Tree("Tea")
# coffee = Tree("Coffee")
# nonAlcoholic = Tree("Non-Alcoholic")
# Alcoholic = Tree("Alcoholic")

# #add child nodes in tree
# rootNode.addChild(hot)
# rootNode.addChild(cold)

# hot.addChild(tea)
# hot.addChild(coffee)

# cold.addChild(nonAlcoholic)
# cold.addChild(Alcoholic)

# print(rootNode)

# --------------------------------------------------------------
# full binary tree:-
# Each node has either 0 or 2 children
# no node has a single child

# complete binary tree:-
# Every level, except possibly the last, is completely filled.
#nodes in the last level are filled from left to right

# perfect binary tree:-
# all internal nodes have exactly two nodes
# all leaf nodes are at the same level

# --------------------------------------------------------------

# class Tree:
#     def __init__(self,data):
#         self.data = data    # instance var(create seperate memory for each instance of class
#         self.children = []
        
#     def addChild(self,child):
#         self.children.append(child)
        
#     def __str__(self,level=0):
#         ret = "  " * level + str(self.data) + "\n"
#         for child in self.children:
#             ret+=child.__str__(level+1)   #recursion
#         return ret
    
# #object creation
# rootNode=Tree("N1")
# n2 = Tree("N2")
# n3 = Tree("N3")
# n4 = Tree("N4")
# n5 = Tree("N5")
# n6 = Tree("N6")
# n7 = Tree("N7")
# n9 = Tree("N9")
# n10 = Tree("N10")

# # add child nodes in tree
# rootNode.addChild(n2)
# rootNode.addChild(n3)

# n2.addChild(n4)
# n2.addChild(n5)

# n3.addChild(n6)
# n3.addChild(n7)

# n4.addChild(n9)
# n4.addChild(n10)

# print(rootNode)

# --------------------------------------------------------------

# class BSTNode:
#     def __init__(self, data):
#         self.data = data
#         self.leftChild = None
#         self.rightChild = None
    
#     def insertNode(rootNode, nodeValue):
#         if rootNode.data == None:
#             rootNode.data = nodeValue
#         elif rootNode.data > nodeValue:
#             if rootNode.leftChild is None:
#                 rootNode.leftChild = BSTNode(nodeValue)
#             else:
#                 BSTNode.inserNode(rootNode.leftChild, nodeValue)
#         else:
#             if rootNode.rightChild is None:
#                 rootNode.rightChild = BSTNode(nodeValue)
#             else:
#                 BSTNode.inserNode(rootNode.rightChild, nodeValue)
# --------------------------------------------------------------

# order traversal:-

# class Node:
#     #create a node in the tree
#     def __init__(self,value):
#         self.value = value
#         self.left = None
#         self.right = None
        
# class BinaryTree:
#     def __init__(self):
#         self.root = None
        
    
#     def insert(self,value):
        
#         if self.root is None:
#             self.root = Node(value)
#         else:
#             self.insertNode(self.root,value)
                    
#     def insertNode(self,rootNode,value):
#         if value < rootNode.value:
#             if rootNode.left is None:
#                 rootNode.left = Node(value)
#             else:
#                 self.insertNode(rootNode.left,value)
#         else:
#             if rootNode.right is None:
#                 rootNode.right = Node(value)
#             else:
#                 self.insertNode(rootNode.left, value)
    
# btObj = BinaryTree()
# btObj.insert(50)
 


    
    

