# def powerofTwo(n):
#     if n == 0:
#         return 1
#     else:
#         power = powerofTwo(n-1)
#     return 2 * power
# powerofTwo(5)
# print(powerofTwo(5))
# --------------------------------------------------------------

# def powerofTwo(n):
#     i = 0
#     power = 1
#     while i < n:
#         power = power * 2
#         i += 1
#     return power
# print(powerofTwo(5))
# --------------------------------------------------------------

#factorial solution
# def factorial(num):
#     if num <= 1:
#         return 1
#     return num * factorial(num-1)

# print(factorial(4))
# --------------------------------------------------------------

# def isPalindrome(strng):
#     if len(strng) == 0:
#         return True
#     if strng[0] != strng[-1]:
#         return False
#     return isPalindrome(strng[1:-1])

# print(isPalindrome("awesome"))
# print(isPalindrome("madam"))

# --------------------------------------------------------------
# def power(base, exponent):
#     if exponent == 0:
#         return 1
#     return base * power(base, exponent-1)
#             #2  *   2(2,2-1)
# print(power(2, 0))
# print(power(2, 2))
# --------------------------------------------------------------
# def capitalizeFirst(arr):
#     result = []
#     if len(arr) == 0:
#         return result
    
#     result.append(arr[0][0].upper() + arr[0][1:])
#     return result + capitalizeFirst(arr[1:])
# print(capitalizeFirst(['car','taco','banana']))
# --------------------------------------------------------------
#product of array solution

# def productOfArray(arr):
#     if len(arr) == 0:
#         return 1
#     return arr[0] * productOfArray(arr[1:])

# print(productOfArray([1,2,3]))
# print(productOfArray([1,2,3,10]))

# --------------------------------------------------------------
#fib solution

# def fib(num):
#     if num <= 2:
#         return 1
#     return fib(num-1) + fib(num-2)

# print(fib(4))
# --------------------------------------------------------------


